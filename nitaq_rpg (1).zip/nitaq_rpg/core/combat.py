"""Pure turn-based combat simulation (no Discord/DB imports)."""
import random
from dataclasses import dataclass


@dataclass
class FightResult:
    won: bool
    rounds: int
    player_hp: int
    monster_hp: int
    drew: bool = False


def _damage(attacker, defender, rng):
    raw = round(attacker["atk"] * rng.uniform(0.85, 1.15))
    return max(1, raw - defender["def"] // 2)


def simulate(player_stats, player_hp, monster, rng=random, max_rounds=40):
    p_hp, m_hp = int(player_hp), int(monster["hp"])
    player_first = player_stats["spd"] >= monster["spd"]
    for rnd in range(1, max_rounds + 1):
        order = ("p", "m") if player_first else ("m", "p")
        for who in order:
            if who == "p":
                m_hp -= _damage(player_stats, monster, rng)
                if m_hp <= 0:
                    return FightResult(True, rnd, p_hp, 0)
            else:
                p_hp -= _damage(monster, player_stats, rng)
                if p_hp <= 0:
                    return FightResult(False, rnd, 0, m_hp)
    return FightResult(False, max_rounds, p_hp, m_hp, drew=True)
