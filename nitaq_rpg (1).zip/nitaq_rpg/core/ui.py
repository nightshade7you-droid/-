"""Embed helpers for a consistent look."""
import discord

import config

COLOR_OK = 0x2ECC71
COLOR_ERR = 0xE74C3C
COLOR_INFO = 0x5865F2
COLOR_WARN = 0xF1C40F


def _embed(title, description, color):
    embed = discord.Embed(title=title, description=description, color=color)
    embed.set_footer(text=config.SERVER_NAME)
    return embed


def success_embed(title, description=None):
    return _embed("\u2705 " + title, description, COLOR_OK)


def error_embed(title, description=None):
    return _embed("\u274c " + title, description, COLOR_ERR)


def info_embed(title, description=None):
    return _embed(title, description, COLOR_INFO)


def warn_embed(title, description=None):
    return _embed("\u26a0\ufe0f " + title, description, COLOR_WARN)


def format_stats(stats, signed=False):
    parts = []
    for key in config.STATS:
        if key in stats:
            value = int(stats[key])
            parts.append(f"{config.STAT_LABELS[key]} {value:+d}" if signed else f"{config.STAT_LABELS[key]} {value}")
    return " | ".join(parts) if parts else "none"


def paginate(items, page, per_page=None):
    """Returns (slice, page, total_pages). Raises BadArgument on a bad page."""
    from discord.ext import commands
    per_page = per_page or config.PAGE_SIZE
    total = max(1, -(-len(items) // per_page))
    if not 1 <= page <= total:
        raise commands.BadArgument(f"Page must be between 1 and {total}.")
    return items[(page - 1) * per_page:page * per_page], page, total


def fmt_duration(seconds):
    seconds = int(seconds)
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    parts = [f"{h}h" if h else "", f"{m}m" if m else "", f"{s}s" if s or not (h or m) else ""]
    return " ".join(p for p in parts if p)
