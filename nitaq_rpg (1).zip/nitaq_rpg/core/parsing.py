"""Safe key=value option parsing for admin commands."""
import re
import shlex

from discord.ext import commands

import config

_SMART_DOUBLE = str.maketrans({"\u201c": '"', "\u201d": '"'})


def parse_kv(raw):
    """Parse: key=value key="value with spaces" ...  Returns dict with lowercase keys."""
    raw = raw.translate(_SMART_DOUBLE)
    lex = shlex.shlex(raw, posix=True)
    lex.whitespace_split = True
    lex.quotes = '"'
    lex.commenters = ""
    lex.escape = ""
    try:
        tokens = list(lex)
    except ValueError:
        raise commands.BadArgument('Unbalanced quotes. Wrap values with spaces in double quotes: desc="my text".')
    out = {}
    for token in tokens:
        if "=" not in token:
            raise commands.BadArgument(f"`{token}` is not valid. Options must look like `key=value`.")
        key, value = token.split("=", 1)
        key = key.strip().lower()
        if not key:
            raise commands.BadArgument("An option has an empty name before `=`.")
        out[key] = value.strip()
    return out


def reject_unknown(opts, allowed):
    unknown = sorted(set(opts) - set(allowed))
    if unknown:
        raise commands.BadArgument(
            f"Unknown option(s): {', '.join('`' + u + '`' for u in unknown)}. "
            f"Allowed: {', '.join('`' + a + '`' for a in sorted(allowed))}."
        )


def get_int(opts, key, default=None, minimum=None, maximum=None):
    if key not in opts:
        if default is None:
            raise commands.BadArgument(f"Missing required option `{key}=<number>`.")
        return default
    try:
        value = int(opts[key])
    except ValueError:
        raise commands.BadArgument(f"`{key}` must be a whole number (got `{opts[key]}`).")
    if minimum is not None and value < minimum:
        raise commands.BadArgument(f"`{key}` must be at least {minimum}.")
    if maximum is not None and value > maximum:
        raise commands.BadArgument(f"`{key}` must be at most {maximum}.")
    return value


def split_names(value):
    return [n.strip() for n in value.split(",") if n.strip()] if value else []


def validate_name(raw, pattern=None, label="Name"):
    name = raw.strip().strip('"').strip()
    if not re.match(pattern or config.NAME_PATTERN, name, re.UNICODE):
        raise commands.BadArgument(
            f"{label} `{name[:40]}` is invalid. Use 2-32 letters, numbers, spaces, `_`, `-` or `'`."
        )
    return name
