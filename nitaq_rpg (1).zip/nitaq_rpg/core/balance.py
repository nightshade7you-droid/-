"""Pure balance logic: no Discord or database imports, easy to unit test."""
import math
from dataclasses import dataclass, field

import config


def weighted_power(stats):
    return round(sum(config.STAT_WEIGHTS[s] * stats.get(s, 0) for s in config.STATS), 2)


@dataclass
class CharacterReport:
    ok: bool
    base_power: float
    trait_power: float
    flaw_power: float
    final_power: float
    final_stats: dict
    problems: list = field(default_factory=list)


def evaluate_character(base_stats, traits, flaws):
    """traits/flaws: lists of {"name", "stat", "amount"} with signed amounts."""
    problems = []

    for stat in config.STATS:
        lo, hi = config.CHAR_STAT_RANGE[stat]
        value = base_stats[stat]
        if not lo <= value <= hi:
            problems.append(f"Base {config.STAT_LABELS[stat]} must be between {lo} and {hi} (got {value}).")

    if len(traits) > config.MAX_TRAITS:
        problems.append(f"Too many traits: max {config.MAX_TRAITS}.")
    if len(flaws) > config.MAX_FLAWS:
        problems.append(f"Too many flaws: max {config.MAX_FLAWS}.")
    if traits and not flaws:
        problems.append("A character with traits needs at least one flaw to offset them.")

    base_power = weighted_power(base_stats)
    if base_power > config.BASE_POWER_CAP:
        problems.append(f"Base stats are too strong: power {base_power:.1f} > cap {config.BASE_POWER_CAP:.0f}.")

    final = dict(base_stats)
    for mod in list(traits) + list(flaws):
        final[mod["stat"]] += mod["amount"]

    trait_power = sum(config.STAT_WEIGHTS[t["stat"]] * t["amount"] for t in traits)
    flaw_power = sum(config.STAT_WEIGHTS[f["stat"]] * abs(f["amount"]) for f in flaws)
    if trait_power > flaw_power + config.FLAW_FREE_ALLOWANCE:
        problems.append(
            f"Traits ({trait_power:.1f} power) are not offset by flaws ({flaw_power:.1f}). "
            f"Rule: trait power <= flaw power + {config.FLAW_FREE_ALLOWANCE:.0f}."
        )

    for stat in config.STATS:
        lo, hi = config.CHAR_STAT_RANGE[stat]
        if not lo <= final[stat] <= hi:
            problems.append(f"Final {config.STAT_LABELS[stat]} would be {final[stat]} (allowed {lo}-{hi}).")

    final_power = weighted_power(final)
    if final_power > config.FINAL_POWER_CAP:
        problems.append(f"Final power {final_power:.1f} exceeds cap {config.FINAL_POWER_CAP:.0f}.")

    return CharacterReport(not problems, base_power, round(trait_power, 2), round(flaw_power, 2),
                           final_power, final, problems)


def evaluate_item(item_type, rarity, stats, price):
    """Returns (ok, problems, power, min_price)."""
    problems = []
    power = weighted_power(stats)
    cap = config.RARITY_POWER_CAPS[rarity]
    min_price = math.ceil(power * config.PRICE_PER_POWER)

    if not stats:
        problems.append("An item needs at least one stat.")
    if item_type == "consumable" and set(stats) - {"hp"}:
        problems.append("Consumables may only use `hp` (healing amount).")
    if power > cap:
        problems.append(f"Power {power:.1f} exceeds the {rarity} cap of {cap}.")
    if price < min_price:
        problems.append(f"Price {price} is too low for power {power:.1f}. Minimum price: {min_price}.")
    return (not problems), problems, power, min_price


def total_stats(base_stats, item_docs):
    total = {s: int(base_stats.get(s, 0)) for s in config.STATS}
    for item in item_docs:
        for stat, value in item.get("stats", {}).items():
            if stat in total:
                total[stat] += int(value)
    return total


def gear_power(item_docs):
    return round(sum(weighted_power(i.get("stats", {})) for i in item_docs), 2)


def level_from_xp(xp):
    return min(config.MAX_LEVEL, 1 + int(xp) // config.XP_PER_LEVEL)


def evaluate_monster(stats, coins, xp):
    """Returns (ok, problems, power)."""
    problems = []
    for stat in config.STATS:
        lo, hi = config.MONSTER_STAT_RANGE[stat]
        if not lo <= stats[stat] <= hi:
            problems.append(f"{config.STAT_LABELS[stat]} must be between {lo} and {hi}.")
    power = weighted_power(stats)
    max_coins = math.floor(power * config.MONSTER_COIN_PER_POWER)
    max_xp = math.floor(power * config.MONSTER_XP_PER_POWER)
    if coins > max_coins:
        problems.append(f"Coin reward {coins} is too high for power {power:.1f}. Max: {max_coins}.")
    if xp > max_xp:
        problems.append(f"XP reward {xp} is too high for power {power:.1f}. Max: {max_xp}.")
    return (not problems), problems, power
