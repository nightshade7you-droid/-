"""ASCII-only logging so Termux terminals never choke on unicode."""
import logging
import os
import sys
from logging.handlers import RotatingFileHandler


class AsciiFormatter(logging.Formatter):
    def format(self, record):
        text = super().format(record)
        return text.encode("ascii", "backslashreplace").decode("ascii")


def setup_logging(level=logging.INFO):
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(errors="backslashreplace")
            sys.stderr.reconfigure(errors="backslashreplace")
        except Exception:
            pass

    fmt = AsciiFormatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s", "%Y-%m-%d %H:%M:%S")
    root = logging.getLogger()
    root.setLevel(level)
    root.handlers.clear()

    console = logging.StreamHandler(sys.stdout)
    console.setFormatter(fmt)
    root.addHandler(console)

    os.makedirs("logs", exist_ok=True)
    file_handler = RotatingFileHandler("logs/bot.log", maxBytes=1_000_000, backupCount=3, encoding="utf-8")
    file_handler.setFormatter(fmt)
    root.addHandler(file_handler)

    logging.getLogger("discord").setLevel(logging.WARNING)
    logging.getLogger("pymongo").setLevel(logging.WARNING)
