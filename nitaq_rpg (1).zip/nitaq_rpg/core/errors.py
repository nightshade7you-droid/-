"""Global error handling: every input mistake returns a syntax guide in Discord."""
import logging
import uuid

import discord
from discord.ext import commands
from pymongo.errors import PyMongoError

from core.ui import error_embed

log = logging.getLogger("rpg.errors")


class WrongChannel(commands.CheckFailure):
    """Raised by the channel-lock check. Handled silently."""


def usage_embed(ctx, command, title, problem):
    embed = error_embed(title, problem)
    usage = f"{ctx.clean_prefix}{command.qualified_name} {command.signature}".strip()
    embed.add_field(name="Required syntax", value=f"`{usage}`", inline=False)
    example = command.extras.get("example")
    if example:
        embed.add_field(name="Example", value=f"`{ctx.clean_prefix}{example}`", inline=False)
    if command.short_doc:
        embed.add_field(name="What it does", value=command.short_doc, inline=False)
    embed.add_field(
        name="Legend",
        value='`<arg>` required, `[arg]` optional. Wrap names containing spaces in quotes: `"Shadow Knight"`.',
        inline=False,
    )
    return embed


async def _reply(ctx, embed):
    try:
        await ctx.reply(embed=embed, mention_author=False)
    except discord.HTTPException:
        log.warning("Could not send error message in channel %s", ctx.channel.id)


class ErrorHandler(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_command_error(self, ctx, error):
        if hasattr(ctx.command, "on_error"):
            return
        cmd = ctx.command

        if isinstance(error, (commands.CommandNotFound, WrongChannel)):
            log.debug("Ignored %s", type(error).__name__)
            return

        if isinstance(error, commands.NoPrivateMessage):
            return await _reply(ctx, error_embed("Server Only", "This bot only works inside the server."))

        if isinstance(error, commands.MissingRequiredArgument):
            return await _reply(ctx, usage_embed(
                ctx, cmd, "Missing Argument", f"You forgot the required argument `{error.param.name}`."))

        if isinstance(error, commands.UserInputError):
            return await _reply(ctx, usage_embed(ctx, cmd, "Invalid Input", str(error)))

        if isinstance(error, commands.MissingPermissions):
            perms = ", ".join(p.replace("_", " ").title() for p in error.missing_permissions)
            return await _reply(ctx, error_embed("No Permission", f"You need: **{perms}**."))

        if isinstance(error, commands.BotMissingPermissions):
            perms = ", ".join(p.replace("_", " ").title() for p in error.missing_permissions)
            return await _reply(ctx, error_embed("Bot Missing Permission", f"I need: **{perms}**."))

        if isinstance(error, commands.CommandOnCooldown):
            return await _reply(ctx, error_embed("Slow Down", f"Try again in **{error.retry_after:.1f}s**."))

        if isinstance(error, commands.CheckFailure):
            return await _reply(ctx, error_embed("Not Allowed", "You cannot use this command here."))

        original = getattr(error, "original", error)

        if isinstance(original, PyMongoError):
            log.error("Database error in command %s: %s", cmd.qualified_name if cmd else "?", type(original).__name__)
            return await _reply(ctx, error_embed("Database Unavailable", "Please try again in a moment."))

        if isinstance(original, discord.Forbidden):
            return await _reply(ctx, error_embed("Missing Access", "I lack the Discord permissions needed for that."))

        ref = uuid.uuid4().hex[:8]
        log.error("Unhandled error ref=%s command=%s user=%s", ref,
                  cmd.qualified_name if cmd else "?", ctx.author.id, exc_info=original)
        await _reply(ctx, error_embed("Unexpected Error", f"Something went wrong. Reference: `{ref}`"))


async def setup(bot):
    await bot.add_cog(ErrorHandler(bot))
