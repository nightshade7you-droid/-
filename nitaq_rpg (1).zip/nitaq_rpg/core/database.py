"""Motor/MongoDB access layer."""
import logging
from datetime import datetime, timedelta, timezone

from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import ASCENDING
from pymongo.errors import DuplicateKeyError

import config

log = logging.getLogger("rpg.db")


def utcnow():
    return datetime.now(timezone.utc)


def utcnow_naive():
    """Mongo returns naive UTC datetimes, so cooldown math uses naive UTC."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


class Database:
    def __init__(self, uri, name):
        self.client = AsyncIOMotorClient(uri, serverSelectionTimeoutMS=5000)
        self.db = self.client[name]
        self.users = self.db["users"]
        self.characters = self.db["custom_characters"]
        self.items = self.db["dynamic_items"]
        self.settings = self.db["settings"]

    async def connect(self):
        await self.client.admin.command("ping")
        log.info("MongoDB connection OK")

    async def close(self):
        self.client.close()

    async def ensure_indexes(self):
        await self.users.create_index([("guild_id", ASCENDING), ("user_id", ASCENDING)], unique=True)
        await self.characters.create_index([("guild_id", ASCENDING), ("name_lower", ASCENDING)], unique=True)
        await self.items.create_index([("guild_id", ASCENDING), ("key", ASCENDING)], unique=True)
        await self.settings.create_index([("guild_id", ASCENDING), ("doc_type", ASCENDING)])
        log.info("Indexes ensured")

    # ---- Channel lock settings ---------------------------------------------
    async def load_allowed_channels(self):
        result = {}
        async for doc in self.settings.find({"doc_type": "channels"}):
            result[doc["guild_id"]] = set(doc.get("channel_ids", []))
        return result

    async def set_allowed_channels(self, guild_id, channel_ids):
        await self.settings.replace_one(
            {"_id": f"channels:{guild_id}"},
            {"_id": f"channels:{guild_id}", "doc_type": "channels", "guild_id": guild_id,
             "channel_ids": sorted(channel_ids), "updated_at": utcnow()},
            upsert=True,
        )

    # ---- Trait registry (stored in settings) -------------------------------
    async def add_trait(self, guild_id, name, kind, stat, signed_amount, description, author_id):
        doc = {"_id": f"trait:{guild_id}:{name.lower()}", "doc_type": "trait", "guild_id": guild_id,
               "name": name, "name_lower": name.lower(), "kind": kind, "stat": stat,
               "amount": signed_amount, "description": description,
               "created_by": author_id, "created_at": utcnow()}
        await self.settings.insert_one(doc)  # raises DuplicateKeyError if it exists
        return doc

    async def remove_trait(self, guild_id, name):
        res = await self.settings.delete_one({"_id": f"trait:{guild_id}:{name.lower()}"})
        return res.deleted_count > 0

    async def get_traits(self, guild_id, names):
        lowered = [n.lower() for n in names]
        cursor = self.settings.find({"doc_type": "trait", "guild_id": guild_id, "name_lower": {"$in": lowered}})
        return {d["name_lower"]: d async for d in cursor}

    async def list_traits(self, guild_id):
        cursor = self.settings.find({"doc_type": "trait", "guild_id": guild_id}).sort("name_lower", 1)
        return await cursor.to_list(length=200)

    # ---- Users --------------------------------------------------------------
    async def ensure_user(self, guild_id, user_id):
        query = {"guild_id": guild_id, "user_id": user_id}
        doc = await self.users.find_one(query)
        if doc:
            return doc
        try:
            await self.users.insert_one({**query, "coins": config.START_COINS, "character": None, "hp": 0,
                                         "inventory": {}, "equipment": {}, "xp": 0, "cd": {}, "created_at": utcnow()})
        except DuplicateKeyError:
            pass
        return await self.users.find_one(query)

    async def claim_cooldown(self, guild_id, user_id, key, seconds, inc=None, set_fields=None):
        """Atomically start a cooldown and apply rewards. Returns (ok, retry_after_seconds)."""
        now = utcnow_naive()
        field = f"cd.{key}"
        query = {"guild_id": guild_id, "user_id": user_id,
                 "$or": [{field: {"$exists": False}}, {field: {"$lte": now - timedelta(seconds=seconds)}}]}
        update = {"$set": {field: now, **(set_fields or {})}}
        if inc:
            update["$inc"] = inc
        res = await self.users.update_one(query, update)
        if res.modified_count:
            return True, 0
        doc = await self.users.find_one({"guild_id": guild_id, "user_id": user_id})
        last = (doc or {}).get("cd", {}).get(key)
        retry = seconds - (now - last).total_seconds() if last else seconds
        return False, max(1, retry)

    # ---- Monster registry (stored in settings) -----------------------------
    async def add_monster(self, guild_id, name, stats, coins, xp, power, description, author_id):
        doc = {"_id": f"monster:{guild_id}:{name.lower()}", "doc_type": "monster", "guild_id": guild_id,
               "name": name, "name_lower": name.lower(), "stats": stats, "coins": coins, "xp": xp,
               "power": power, "description": description, "created_by": author_id, "created_at": utcnow()}
        await self.settings.insert_one(doc)
        return doc

    async def get_monster(self, guild_id, name):
        return await self.settings.find_one({"_id": f"monster:{guild_id}:{name.strip().strip(chr(34)).lower()}"})

    async def remove_monster(self, guild_id, name):
        res = await self.settings.delete_one({"_id": f"monster:{guild_id}:{name.strip().strip(chr(34)).lower()}"})
        return res.deleted_count > 0

    async def list_monsters(self, guild_id):
        cursor = self.settings.find({"doc_type": "monster", "guild_id": guild_id}).sort("power", 1)
        return await cursor.to_list(length=500)
