"""Embed-based help command that always shows syntax and examples."""
import discord
from discord.ext import commands

from core.ui import error_embed, info_embed


class EmbedHelp(commands.HelpCommand):
    async def send_bot_help(self, mapping):
        embed = info_embed("Command Guide", f"Use `{self.context.clean_prefix}help <command>` for syntax and examples.")
        for cog, cmds in mapping.items():
            visible = await self.filter_commands(cmds, sort=True)
            if visible:
                embed.add_field(name=cog.qualified_name if cog else "General",
                                value=" ".join(f"`{c.name}`" for c in visible), inline=False)
        await self.get_destination().send(embed=embed)

    async def send_command_help(self, command):
        prefix = self.context.clean_prefix
        embed = info_embed(f"{prefix}{command.qualified_name}", command.help or "No description.")
        embed.add_field(name="Syntax", value=f"`{prefix}{command.qualified_name} {command.signature}`".strip(), inline=False)
        if command.extras.get("example"):
            embed.add_field(name="Example", value=f"`{prefix}{command.extras['example']}`", inline=False)
        await self.get_destination().send(embed=embed)

    async def send_error_message(self, error):
        await self.get_destination().send(embed=error_embed("Help", str(error)))
