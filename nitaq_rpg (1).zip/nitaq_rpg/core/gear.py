"""Shared equipment helpers."""


async def load_equipped(db, guild_id, user):
    equipment = user.get("equipment", {})
    if not equipment:
        return {}
    cursor = db.items.find({"guild_id": guild_id, "key": {"$in": list(equipment.values())}})
    by_key = {d["key"]: d async for d in cursor}
    return {slot: by_key[key] for slot, key in equipment.items() if key in by_key}
