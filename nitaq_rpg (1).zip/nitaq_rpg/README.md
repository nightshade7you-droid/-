# Nitaq RPG Engine

## Termux setup
    pkg update && pkg install python clang rust libffi openssl
    pip install -r requirements.txt
    cp .env.example .env   # then edit .env and put your bot token there
    python main.py

NEVER paste the token into the code or share it. If it leaks, press "Reset Token" in the Discord developer portal.
Use MongoDB Atlas (free tier) for MONGO_URI (needs MongoDB 4.2+); MongoDB does not run natively on Termux.
Enable "Message Content Intent" in the Discord developer portal.

## First run (admin, needs Manage Server)
1. `=setup #channel`  (until then the bot ignores everything except admin setup commands)
2. `=trait_add Sharp_Blade trait atk 8` and `=trait_add Brittle_Armor flaw def 6`
3. `=char_preview "Shadow Knight" hp=100 atk=18 def=12 spd=10 traits=Sharp_Blade flaws=Brittle_Armor`, then `=char_create ...` (same args)
4. `=item_create "Iron Sword" type=weapon rarity=common price=60 atk=8`
5. `=monster_create Goblin hp=60 atk=10 def=5 spd=6 coins=20 xp=15`

## Admin commands
setup, channel_add, channel_remove, channels, trait_add, trait_remove, char_preview, char_create, char_edit,
char_delete, item_create, item_edit, item_delete, monster_create, monster_delete, give_item, give_coins, player_reset

## Player commands
characters, char_info, start, profile, shop, buy, sell, inventory, equip, unequip, use, daily, work,
monsters, fight, rest, trait_list, item_info

## Balance rules (numbers in config.py)
- Characters: base power cap, final power cap, every trait must be offset by flaws.
- Items: power cap per rarity, minimum price per power.
- Gear: combined power of equipped items is capped (GEAR_POWER_CAP), so stacking top items is blocked.
- Monsters: coin/XP rewards are capped by monster power, so weak monsters cannot be farmed for big rewards.
- Cooldowns (daily, work, fight, rest) are stored in MongoDB and survive restarts.
