"""Earning and selling coins."""
import logging
import random

from discord.ext import commands

import config
from core.ui import error_embed, fmt_duration, success_embed

log = logging.getLogger("rpg.economy")


class Economy(commands.Cog, name="Economy"):
    def __init__(self, bot):
        self.bot = bot

    async def _claim(self, ctx, key, seconds, coins):
        await self.bot.db.ensure_user(ctx.guild.id, ctx.author.id)
        ok, retry = await self.bot.db.claim_cooldown(ctx.guild.id, ctx.author.id, key, seconds, inc={"coins": coins})
        if not ok:
            await ctx.reply(embed=error_embed("Cooldown", f"Come back in **{fmt_duration(retry)}**."),
                            mention_author=False)
        return ok

    @commands.command(name="daily", extras={"example": "daily"})
    async def daily(self, ctx):
        """Claim your daily coins (once every 24 hours)."""
        if await self._claim(ctx, "daily", config.DAILY_COOLDOWN, config.DAILY_COINS):
            await ctx.reply(embed=success_embed("Daily Reward", f"You received **{config.DAILY_COINS}** coins."),
                            mention_author=False)

    @commands.command(name="work", extras={"example": "work"})
    async def work(self, ctx):
        """Do a job for a few coins (once per hour)."""
        coins = random.randint(*config.WORK_RANGE)
        if await self._claim(ctx, "work", config.WORK_COOLDOWN, coins):
            await ctx.reply(embed=success_embed("Work Done", f"You earned **{coins}** coins."), mention_author=False)

    @commands.command(name="sell", extras={"example": 'sell "Iron Sword" 1'})
    async def sell(self, ctx, item_name: str, quantity: int = 1):
        """Sell an item back for part of its price. Quote names that contain spaces."""
        if not 1 <= quantity <= 99:
            raise commands.BadArgument("`quantity` must be between 1 and 99.")
        key = item_name.strip().strip('"').lower()
        item = await self.bot.db.items.find_one({"guild_id": ctx.guild.id, "key": key})
        if not item:
            raise commands.BadArgument(f"No item named `{item_name.strip()[:40]}`.")
        await self.bot.db.ensure_user(ctx.guild.id, ctx.author.id)
        who = {"guild_id": ctx.guild.id, "user_id": ctx.author.id}
        gain = int(item["price"] * config.SELL_RATIO) * quantity
        res = await self.bot.db.users.update_one(
            {**who, f"inventory.{key}": {"$gte": quantity}},
            {"$inc": {"coins": gain, f"inventory.{key}": -quantity}})
        if not res.modified_count:
            raise commands.BadArgument(f"You do not have {quantity}x `{item['name']}`.")
        user = await self.bot.db.users.find_one(who)
        if user.get("inventory", {}).get(key, 0) < 1 and user.get("equipment", {}).get(item["type"]) == key:
            await self.bot.db.users.update_one(who, {"$unset": {f"equipment.{item['type']}": ""}})
        await ctx.reply(embed=success_embed("Sold", f"{quantity}x **{item['name']}** for {gain} coins."),
                        mention_author=False)


async def setup(bot):
    await bot.add_cog(Economy(bot))
