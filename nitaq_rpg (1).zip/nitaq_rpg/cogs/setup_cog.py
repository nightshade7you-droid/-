"""MODULE 1: channel lock management."""
import logging

import discord
from discord.ext import commands

from core.ui import error_embed, info_embed, success_embed, warn_embed

log = logging.getLogger("rpg.setup")


class SetupCog(commands.Cog, name="Setup"):
    def __init__(self, bot):
        self.bot = bot

    def _warn_if_no_send(self, ctx, channel):
        if not channel.permissions_for(ctx.guild.me).send_messages:
            return warn_embed("Heads up", f"I cannot send messages in {channel.mention}. Fix my permissions there.")
        return None

    @commands.command(name="setup", extras={"example": "setup #rpg-zone"})
    @commands.has_permissions(manage_guild=True)
    async def setup_cmd(self, ctx, channel: discord.TextChannel):
        """Lock the bot to ONE channel (replaces the current list)."""
        await self.bot.db.set_allowed_channels(ctx.guild.id, [channel.id])
        self.bot.allowed_channels[ctx.guild.id] = {channel.id}
        log.info("Guild %s locked to channel %s", ctx.guild.id, channel.id)
        await ctx.reply(embed=success_embed("Setup Complete", f"The bot now only works in {channel.mention}."),
                        mention_author=False)
        warning = self._warn_if_no_send(ctx, channel)
        if warning:
            await ctx.send(embed=warning)

    @commands.command(name="channel_add", extras={"example": "channel_add #arena"})
    @commands.has_permissions(manage_guild=True)
    async def channel_add(self, ctx, channel: discord.TextChannel):
        """Allow the bot in an additional channel."""
        allowed = set(self.bot.allowed_channels.get(ctx.guild.id, set()))
        allowed.add(channel.id)
        await self.bot.db.set_allowed_channels(ctx.guild.id, allowed)
        self.bot.allowed_channels[ctx.guild.id] = allowed
        await ctx.reply(embed=success_embed("Channel Added", f"{channel.mention} is now allowed."), mention_author=False)

    @commands.command(name="channel_remove", extras={"example": "channel_remove #arena"})
    @commands.has_permissions(manage_guild=True)
    async def channel_remove(self, ctx, channel: discord.TextChannel):
        """Remove a channel from the allowed list."""
        allowed = set(self.bot.allowed_channels.get(ctx.guild.id, set()))
        if channel.id not in allowed:
            return await ctx.reply(embed=error_embed("Not In List", f"{channel.mention} was not allowed."),
                                   mention_author=False)
        allowed.discard(channel.id)
        await self.bot.db.set_allowed_channels(ctx.guild.id, allowed)
        self.bot.allowed_channels[ctx.guild.id] = allowed
        await ctx.reply(embed=success_embed("Channel Removed", f"{channel.mention} removed."), mention_author=False)

    @commands.command(name="channels", extras={"example": "channels"})
    @commands.has_permissions(manage_guild=True)
    async def channels(self, ctx):
        """Show the channels the bot is locked to."""
        allowed = self.bot.allowed_channels.get(ctx.guild.id, set())
        text = "\n".join(f"<#{c}>" for c in sorted(allowed)) or "None. Run the setup command first."
        await ctx.reply(embed=info_embed("Allowed Channels", text), mention_author=False)


async def setup(bot):
    await bot.add_cog(SetupCog(bot))
