"""Admin-driven trait/flaw registry and balanced custom characters."""
import logging

import discord
from discord.ext import commands
from pymongo.errors import DuplicateKeyError

import config
from core.balance import evaluate_character
from core.database import utcnow
from core.parsing import get_int, parse_kv, reject_unknown, split_names, validate_name
from core.ui import error_embed, format_stats, info_embed, success_embed

log = logging.getLogger("rpg.characters")

CHAR_KEYS = {"hp", "atk", "def", "spd", "traits", "flaws", "desc"}
CHAR_EXAMPLE = ('char_create "Shadow Knight" hp=100 atk=18 def=12 spd=10 '
                'traits=Sharp_Blade flaws=Brittle_Armor desc="A fallen knight"')


def report_embed(name, report, saved):
    if report.ok:
        title = "Character Created" if saved else "Balance Check Passed"
        embed = success_embed(title, f"**{name}** is balanced.")
    else:
        embed = error_embed("Balance Check Failed", f"**{name}** was NOT saved." if not saved else None)
        embed.add_field(name="Problems", value="\n".join(f"- {p}" for p in report.problems)[:1000], inline=False)
    embed.add_field(name="Final stats", value=format_stats(report.final_stats), inline=False)
    embed.add_field(
        name="Power",
        value=(f"Base {report.base_power:.1f}/{config.BASE_POWER_CAP:.0f} | Traits +{report.trait_power:.1f} | "
               f"Flaws -{report.flaw_power:.1f} | Final {report.final_power:.1f}/{config.FINAL_POWER_CAP:.0f}"),
        inline=False,
    )
    return embed


class AdminCharacters(commands.Cog, name="Characters"):
    def __init__(self, bot):
        self.bot = bot

    # ---- Trait registry ----------------------------------------------------
    @commands.command(name="trait_add",
                      extras={"example": 'trait_add Sharp_Blade trait atk 8 "Honed edge, more damage"'})
    @commands.has_permissions(manage_guild=True)
    async def trait_add(self, ctx, name: str, kind: str, stat: str, amount: int, *, description: str = ""):
        """Create a trait (positive) or flaw (negative) stat modifier."""
        name = validate_name(name, config.TRAIT_NAME_PATTERN, "Trait name")
        kind, stat = kind.lower(), stat.lower()
        if kind not in ("trait", "flaw"):
            raise commands.BadArgument("`kind` must be `trait` or `flaw`.")
        if stat not in config.STATS:
            raise commands.BadArgument(f"`stat` must be one of: {', '.join(config.STATS)}.")
        limit = config.TRAIT_MAX_MAGNITUDE[stat]
        if not 1 <= amount <= limit:
            raise commands.BadArgument(f"`amount` for {stat} must be between 1 and {limit}. Give a positive number; "
                                       "the sign is set by `kind`.")
        signed = amount if kind == "trait" else -amount
        try:
            await self.bot.db.add_trait(ctx.guild.id, name, kind, stat, signed, description.strip()[:200], ctx.author.id)
        except DuplicateKeyError:
            raise commands.BadArgument(f"A trait or flaw named `{name}` already exists.")
        log.info("Trait added guild=%s by=%s kind=%s stat=%s amount=%s", ctx.guild.id, ctx.author.id, kind, stat, signed)
        await ctx.reply(embed=success_embed("Trait Saved", f"**{name}** ({kind}): {stat.upper()} {signed:+d}"),
                        mention_author=False)

    @commands.command(name="trait_remove", extras={"example": "trait_remove Sharp_Blade"})
    @commands.has_permissions(manage_guild=True)
    async def trait_remove(self, ctx, *, name: str):
        """Delete a trait/flaw from the registry (existing characters keep their copy)."""
        if not await self.bot.db.remove_trait(ctx.guild.id, name.strip()):
            raise commands.BadArgument(f"No trait named `{name.strip()[:40]}`. See the trait_list command.")
        await ctx.reply(embed=success_embed("Trait Removed", name.strip()), mention_author=False)

    @commands.command(name="trait_list", extras={"example": "trait_list"})
    async def trait_list(self, ctx):
        """List all traits and flaws available for custom characters."""
        docs = await self.bot.db.list_traits(ctx.guild.id)
        if not docs:
            return await ctx.reply(embed=info_embed("Traits", "No traits yet. Admins can add them with trait_add."),
                                   mention_author=False)
        traits = [f"`{d['name']}` {d['stat'].upper()} {d['amount']:+d}" for d in docs if d["kind"] == "trait"]
        flaws = [f"`{d['name']}` {d['stat'].upper()} {d['amount']:+d}" for d in docs if d["kind"] == "flaw"]
        embed = info_embed("Traits and Flaws")
        embed.add_field(name="Traits", value="\n".join(traits)[:1000] or "none", inline=True)
        embed.add_field(name="Flaws", value="\n".join(flaws)[:1000] or "none", inline=True)
        await ctx.reply(embed=embed, mention_author=False)

    # ---- Characters --------------------------------------------------------
    async def _build(self, ctx, name, options, existing=None):
        name = validate_name(name, label="Character name")
        opts = parse_kv(options)
        reject_unknown(opts, CHAR_KEYS)
        if existing:
            base = {s: get_int(opts, s, default=existing["base_stats"][s]) for s in config.STATS}
            trait_names = split_names(opts["traits"]) if "traits" in opts else [t["name"] for t in existing["traits"]]
            flaw_names = split_names(opts["flaws"]) if "flaws" in opts else [f["name"] for f in existing["flaws"]]
        else:
            base = {s: get_int(opts, s) for s in config.STATS}
            trait_names = split_names(opts.get("traits", ""))
            flaw_names = split_names(opts.get("flaws", ""))
        everything = [n.lower() for n in trait_names + flaw_names]
        if len(set(everything)) != len(everything):
            raise commands.BadArgument("The same trait/flaw was listed more than once.")

        defs = await self.bot.db.get_traits(ctx.guild.id, trait_names + flaw_names)

        def resolve(names, kind):
            mods = []
            for n in names:
                doc = defs.get(n.lower())
                if not doc:
                    raise commands.BadArgument(f"Unknown {kind} `{n[:30]}`. Check the trait_list command.")
                if doc["kind"] != kind:
                    other = "flaws" if kind == "trait" else "traits"
                    raise commands.BadArgument(f"`{doc['name']}` is a {doc['kind']}; put it under `{other}=`.")
                mods.append({"name": doc["name"], "stat": doc["stat"], "amount": doc["amount"]})
            return mods

        traits = resolve(trait_names, "trait")
        flaws = resolve(flaw_names, "flaw")
        report = evaluate_character(base, traits, flaws)
        default_desc = existing.get("description", "") if existing else ""
        return name, opts.get("desc", default_desc)[:200], base, traits, flaws, report

    @commands.command(name="char_preview", extras={"example": CHAR_EXAMPLE.replace("char_create", "char_preview")})
    @commands.has_permissions(manage_guild=True)
    async def char_preview(self, ctx, name: str, *, options: str):
        """Test a character against the balance rules without saving it."""
        name, _, _, _, _, report = await self._build(ctx, name, options)
        await ctx.reply(embed=report_embed(name, report, saved=False), mention_author=False)

    @commands.command(name="char_create", extras={"example": CHAR_EXAMPLE})
    @commands.has_permissions(manage_guild=True)
    async def char_create(self, ctx, name: str, *, options: str):
        """Create a balanced custom character (options: hp atk def spd traits flaws desc)."""
        name, desc, base, traits, flaws, report = await self._build(ctx, name, options)
        if not report.ok:
            return await ctx.reply(embed=report_embed(name, report, saved=False), mention_author=False)
        doc = {"guild_id": ctx.guild.id, "name": name, "name_lower": name.lower(), "description": desc,
               "base_stats": base, "traits": traits, "flaws": flaws, "final_stats": report.final_stats,
               "power": report.final_power, "created_by": ctx.author.id, "created_at": utcnow()}
        try:
            await self.bot.db.characters.insert_one(doc)
        except DuplicateKeyError:
            raise commands.BadArgument(f"A character named `{name}` already exists.")
        log.info("Character created guild=%s by=%s power=%.1f", ctx.guild.id, ctx.author.id, report.final_power)
        await ctx.reply(embed=report_embed(name, report, saved=True), mention_author=False)

    @commands.command(name="char_edit", extras={"example": 'char_edit "Shadow Knight" atk=20 flaws=Brittle_Armor'})
    @commands.has_permissions(manage_guild=True)
    async def char_edit(self, ctx, name: str, *, options: str):
        """Edit a character; only the options you give change. Players who already picked it keep their copy."""
        existing = await self.bot.db.characters.find_one(
            {"guild_id": ctx.guild.id, "name_lower": validate_name(name, label="Character name").lower()})
        if not existing:
            raise commands.BadArgument(f"No character named `{name.strip()[:40]}`.")
        name, desc, base, traits, flaws, report = await self._build(ctx, existing["name"], options, existing)
        if not report.ok:
            return await ctx.reply(embed=report_embed(name, report, saved=False), mention_author=False)
        await self.bot.db.characters.update_one(
            {"_id": existing["_id"]},
            {"$set": {"description": desc, "base_stats": base, "traits": traits, "flaws": flaws,
                      "final_stats": report.final_stats, "power": report.final_power}})
        log.info("Character edited guild=%s by=%s", ctx.guild.id, ctx.author.id)
        embed = report_embed(name, report, saved=True)
        embed.title = "\u2705 Character Updated"
        await ctx.reply(embed=embed, mention_author=False)

    @commands.command(name="char_info", extras={"example": "char_info Shadow Knight"})
    async def char_info(self, ctx, *, name: str):
        """Show full details of a character."""
        doc = await self.bot.db.characters.find_one(
            {"guild_id": ctx.guild.id, "name_lower": name.strip().strip('"').lower()})
        if not doc:
            raise commands.BadArgument(f"No character named `{name.strip()[:40]}`.")
        embed = info_embed(doc["name"], doc.get("description") or "No description.")
        embed.add_field(name="Base stats", value=format_stats(doc["base_stats"]), inline=False)
        embed.add_field(name="Final stats", value=format_stats(doc["final_stats"]), inline=False)
        embed.add_field(name="Traits", value="\n".join(
            f"{t['name']}: {t['stat'].upper()} {t['amount']:+d}" for t in doc["traits"]) or "none", inline=True)
        embed.add_field(name="Flaws", value="\n".join(
            f"{f['name']}: {f['stat'].upper()} {f['amount']:+d}" for f in doc["flaws"]) or "none", inline=True)
        await ctx.reply(embed=embed, mention_author=False)

    @commands.command(name="char_delete", extras={"example": 'char_delete Shadow Knight'})
    @commands.has_permissions(manage_guild=True)
    async def char_delete(self, ctx, *, name: str):
        """Delete a custom character (players who already picked it keep it)."""
        res = await self.bot.db.characters.delete_one({"guild_id": ctx.guild.id, "name_lower": name.strip().strip('"').lower()})
        if not res.deleted_count:
            raise commands.BadArgument(f"No character named `{name.strip()[:40]}`.")
        await ctx.reply(embed=success_embed("Character Deleted", name.strip()), mention_author=False)


async def setup(bot):
    await bot.add_cog(AdminCharacters(bot))
