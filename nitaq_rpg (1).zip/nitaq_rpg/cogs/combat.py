"""Monsters (admin-created), fighting and resting."""
import logging

import discord
from discord.ext import commands
from pymongo.errors import DuplicateKeyError

import config
from core.balance import evaluate_monster, level_from_xp, total_stats
from core.combat import simulate
from core.gear import load_equipped
from core.parsing import get_int, parse_kv, reject_unknown, validate_name
from core.ui import error_embed, fmt_duration, format_stats, info_embed, paginate, success_embed, warn_embed

log = logging.getLogger("rpg.combat")

MONSTER_KEYS = {"hp", "atk", "def", "spd", "coins", "xp", "desc"}


class Combat(commands.Cog, name="Combat"):
    def __init__(self, bot):
        self.bot = bot

    # ---- Admin: monsters ---------------------------------------------------
    @commands.command(name="monster_create",
                      extras={"example": 'monster_create Goblin hp=60 atk=10 def=5 spd=6 coins=20 xp=15 desc="A small thief"'})
    @commands.has_permissions(manage_guild=True)
    async def monster_create(self, ctx, name: str, *, options: str):
        """Create a monster (options: hp atk def spd coins xp desc). Rewards are capped by its power."""
        name = validate_name(name, label="Monster name")
        opts = parse_kv(options)
        reject_unknown(opts, MONSTER_KEYS)
        stats = {s: get_int(opts, s, minimum=0, maximum=100000) for s in config.STATS}
        coins = get_int(opts, "coins", default=0, minimum=0, maximum=10_000_000)
        xp = get_int(opts, "xp", default=0, minimum=0, maximum=10_000_000)
        ok, problems, power = evaluate_monster(stats, coins, xp)
        if not ok:
            embed = error_embed("Balance Check Failed", f"**{name}** was NOT saved.")
            embed.add_field(name="Problems", value="\n".join(f"- {p}" for p in problems)[:1000], inline=False)
            return await ctx.reply(embed=embed, mention_author=False)
        try:
            await self.bot.db.add_monster(ctx.guild.id, name, stats, coins, xp, power, opts.get("desc", "")[:200],
                                          ctx.author.id)
        except DuplicateKeyError:
            raise commands.BadArgument(f"A monster named `{name}` already exists.")
        log.info("Monster created guild=%s by=%s power=%.1f", ctx.guild.id, ctx.author.id, power)
        embed = success_embed("Monster Created", f"**{name}** (power {power:.1f})")
        embed.add_field(name="Stats", value=format_stats(stats), inline=False)
        embed.add_field(name="Rewards", value=f"{coins} coins | {xp} XP", inline=False)
        await ctx.reply(embed=embed, mention_author=False)

    @commands.command(name="monster_delete", extras={"example": "monster_delete Goblin"})
    @commands.has_permissions(manage_guild=True)
    async def monster_delete(self, ctx, *, name: str):
        """Delete a monster."""
        if not await self.bot.db.remove_monster(ctx.guild.id, name):
            raise commands.BadArgument(f"No monster named `{name.strip()[:40]}`.")
        await ctx.reply(embed=success_embed("Monster Deleted", name.strip()), mention_author=False)

    @commands.command(name="monsters", extras={"example": "monsters 1"})
    async def monsters(self, ctx, page: int = 1):
        """List monsters you can fight."""
        docs = await self.bot.db.list_monsters(ctx.guild.id)
        if not docs:
            return await ctx.reply(embed=info_embed("Monsters", "No monsters yet. Admins can add them with monster_create."),
                                   mention_author=False)
        chunk, page, total = paginate(docs, page)
        embed = info_embed("Monsters", f"Fight one with the fight command. Page {page}/{total}")
        for d in chunk:
            embed.add_field(name=d["name"],
                            value=f"{format_stats(d['stats'])}\nReward: {d['coins']} coins, {d['xp']} XP", inline=False)
        await ctx.reply(embed=embed, mention_author=False)

    # ---- Player ------------------------------------------------------------
    async def _ready_user(self, ctx):
        user = await self.bot.db.ensure_user(ctx.guild.id, ctx.author.id)
        if not user.get("character"):
            raise commands.BadArgument("You have no character yet. Pick one with the start command.")
        equipped = await load_equipped(self.bot.db, ctx.guild.id, user)
        stats = total_stats(user["character"]["stats"], equipped.values())
        return user, stats

    @commands.command(name="fight", extras={"example": "fight Goblin"})
    async def fight(self, ctx, *, monster_name: str):
        """Fight a monster for coins and XP."""
        user, stats = await self._ready_user(ctx)
        monster = await self.bot.db.get_monster(ctx.guild.id, monster_name)
        if not monster:
            raise commands.BadArgument(f"No monster named `{monster_name.strip()[:40]}`. See the monsters command.")
        hp = min(user.get("hp", 0), stats["hp"])
        if hp < 1:
            raise commands.BadArgument("You have no HP left. Use the rest command or a potion.")
        ok, retry = await self.bot.db.claim_cooldown(ctx.guild.id, ctx.author.id, "fight", config.FIGHT_COOLDOWN)
        if not ok:
            return await ctx.reply(embed=error_embed("Cooldown", f"Catch your breath for **{fmt_duration(retry)}**."),
                                   mention_author=False)
        result = simulate(stats, hp, monster["stats"])
        who = {"guild_id": ctx.guild.id, "user_id": ctx.author.id}
        old_level = level_from_xp(user.get("xp", 0))
        if result.won:
            await self.bot.db.users.update_one(
                who, {"$set": {"hp": max(1, result.player_hp)}, "$inc": {"coins": monster["coins"], "xp": monster["xp"]}})
            new_level = level_from_xp(user.get("xp", 0) + monster["xp"])
            embed = success_embed("Victory", f"You defeated **{monster['name']}** in {result.rounds} round(s).")
            embed.add_field(name="Rewards", value=f"{monster['coins']} coins | {monster['xp']} XP", inline=True)
            if new_level > old_level:
                embed.add_field(name="Level Up", value=f"You are now level {new_level}!", inline=True)
        else:
            left = 1 if not result.drew else max(1, result.player_hp)
            await self.bot.db.users.update_one(who, {"$set": {"hp": left}})
            title = "Stalemate" if result.drew else "Defeat"
            text = (f"You and **{monster['name']}** could not finish each other." if result.drew
                    else f"**{monster['name']}** beat you after {result.rounds} round(s). No rewards.")
            embed = warn_embed(title, text)
        embed.add_field(name="Your HP", value=f"{max(1, result.player_hp) if result.won else left}/{stats['hp']}",
                        inline=True)
        await ctx.reply(embed=embed, mention_author=False)

    @commands.command(name="rest", extras={"example": "rest"})
    async def rest(self, ctx):
        """Fully restore your HP (every 30 minutes)."""
        user, stats = await self._ready_user(ctx)
        if user.get("hp", 0) >= stats["hp"]:
            raise commands.BadArgument("You are already at full HP.")
        ok, retry = await self.bot.db.claim_cooldown(ctx.guild.id, ctx.author.id, "rest", config.REST_COOLDOWN,
                                                     set_fields={"hp": stats["hp"]})
        if not ok:
            return await ctx.reply(embed=error_embed("Cooldown", f"You can rest again in **{fmt_duration(retry)}**."),
                                   mention_author=False)
        await ctx.reply(embed=success_embed("Rested", f"HP restored to {stats['hp']}/{stats['hp']}."),
                        mention_author=False)


async def setup(bot):
    await bot.add_cog(Combat(bot))
