"""Player-facing commands."""
import logging

import discord
from discord.ext import commands

import config
from core.balance import gear_power, level_from_xp, total_stats
from core.gear import load_equipped
from core.ui import error_embed, format_stats, info_embed, paginate, success_embed

log = logging.getLogger("rpg.player")


class Player(commands.Cog, name="Player"):
    def __init__(self, bot):
        self.bot = bot

    @staticmethod
    def _need_character(user):
        if not user.get("character"):
            raise commands.BadArgument("You have no character yet. Pick one with the start command.")

    @commands.command(name="characters", extras={"example": "characters 2"})
    async def characters(self, ctx, page: int = 1):
        """List the characters you can start with."""
        docs = await self.bot.db.characters.find({"guild_id": ctx.guild.id}).sort("name_lower", 1).to_list(length=500)
        if not docs:
            return await ctx.reply(embed=info_embed("Characters", "No characters exist yet. Ask an admin."),
                                   mention_author=False)
        chunk, page, total = paginate(docs, page)
        embed = info_embed("Available Characters", f"Pick one with the start command. Page {page}/{total}")
        for d in chunk:
            flaws = ", ".join(f["name"] for f in d["flaws"]) or "none"
            traits = ", ".join(t["name"] for t in d["traits"]) or "none"
            embed.add_field(name=d["name"],
                            value=f"{format_stats(d['final_stats'])}\nTraits: {traits}\nFlaws: {flaws}", inline=False)
        await ctx.reply(embed=embed, mention_author=False)

    @commands.command(name="start", extras={"example": "start Shadow Knight"})
    async def start(self, ctx, *, character_name: str):
        """Choose your character (one time only)."""
        user = await self.bot.db.ensure_user(ctx.guild.id, ctx.author.id)
        if user.get("character"):
            raise commands.BadArgument("You already have a character.")
        char = await self.bot.db.characters.find_one(
            {"guild_id": ctx.guild.id, "name_lower": character_name.strip().strip('"').lower()})
        if not char:
            raise commands.BadArgument(f"No character named `{character_name.strip()[:40]}`. See the characters command.")
        snapshot = {"name": char["name"], "stats": char["final_stats"],
                    "traits": [t["name"] for t in char["traits"]], "flaws": [f["name"] for f in char["flaws"]]}
        res = await self.bot.db.users.update_one(
            {"guild_id": ctx.guild.id, "user_id": ctx.author.id, "character": None},
            {"$set": {"character": snapshot, "hp": char["final_stats"]["hp"]}})
        if not res.modified_count:
            raise commands.BadArgument("You already have a character.")
        log.info("Player started guild=%s user=%s", ctx.guild.id, ctx.author.id)
        await ctx.reply(embed=success_embed("Welcome!", f"You are now **{char['name']}**."), mention_author=False)

    @commands.command(name="profile", extras={"example": "profile @Player"})
    async def profile(self, ctx, member: discord.Member = None):
        """Show a player's profile (yours by default)."""
        member = member or ctx.author
        user = await self.bot.db.ensure_user(ctx.guild.id, member.id)
        char = user.get("character")
        if not char:
            raise commands.BadArgument("That player has not picked a character yet.")
        equipped = await load_equipped(self.bot.db, ctx.guild.id, user)
        stats = total_stats(char["stats"], equipped.values())
        hp = min(user.get("hp", 0), stats["hp"])
        xp = user.get("xp", 0)
        embed = info_embed(f"{char['name']} - {member.display_name}")
        embed.add_field(name="Level", value=f"{level_from_xp(xp)} ({xp} XP)", inline=True)
        embed.add_field(name="HP", value=f"{hp}/{stats['hp']}", inline=True)
        embed.add_field(name="Coins", value=str(user.get("coins", 0)), inline=True)
        embed.add_field(name="Stats", value=format_stats(stats), inline=False)
        embed.add_field(name="Traits", value=", ".join(char["traits"]) or "none", inline=True)
        embed.add_field(name="Flaws", value=", ".join(char["flaws"]) or "none", inline=True)
        gear = "\n".join(f"{slot.title()}: {item['name']}" for slot, item in equipped.items()) or "nothing equipped"
        embed.add_field(name=f"Equipment (power {gear_power(equipped.values()):.0f}/{config.GEAR_POWER_CAP:.0f})",
                        value=gear, inline=False)
        await ctx.reply(embed=embed, mention_author=False)

    @commands.command(name="shop", extras={"example": "shop weapon 2"})
    async def shop(self, ctx, item_type: str = None, page: int = 1):
        """Browse items for sale. Optional: type (weapon, armor, accessory, consumable) and page."""
        if item_type and item_type.isdigit():
            item_type, page = None, int(item_type)
        query = {"guild_id": ctx.guild.id}
        if item_type:
            item_type = item_type.lower()
            if item_type not in config.ITEM_TYPES:
                raise commands.BadArgument(f"Type must be one of: {', '.join(config.ITEM_TYPES)}.")
            query["type"] = item_type
        docs = await self.bot.db.items.find(query).sort("price", 1).to_list(length=1000)
        if not docs:
            return await ctx.reply(embed=info_embed("Shop", "Nothing for sale."), mention_author=False)
        chunk, page, total = paginate(docs, page)
        lines = [f"**{d['name']}** ({d['rarity']} {d['type']}) - {d['price']} coins\n{format_stats(d['stats'], True)}"
                 for d in chunk]
        embed = info_embed("Shop", "\n\n".join(lines)[:4000])
        embed.set_footer(text=f"Page {page}/{total} | {config.SERVER_NAME}")
        await ctx.reply(embed=embed, mention_author=False)

    @commands.command(name="buy", extras={"example": 'buy "Iron Sword" 1'})
    async def buy(self, ctx, item_name: str, quantity: int = 1):
        """Buy an item. Quote names that contain spaces."""
        if not 1 <= quantity <= 99:
            raise commands.BadArgument("`quantity` must be between 1 and 99.")
        item = await self.bot.db.items.find_one({"guild_id": ctx.guild.id, "key": item_name.strip().lower()})
        if not item:
            raise commands.BadArgument(f"No item named `{item_name[:40]}`.")
        await self.bot.db.ensure_user(ctx.guild.id, ctx.author.id)
        cost = item["price"] * quantity
        res = await self.bot.db.users.update_one(
            {"guild_id": ctx.guild.id, "user_id": ctx.author.id, "coins": {"$gte": cost}},
            {"$inc": {"coins": -cost, f"inventory.{item['key']}": quantity}})
        if not res.modified_count:
            raise commands.BadArgument(f"Not enough coins. You need {cost}.")
        await ctx.reply(embed=success_embed("Purchased", f"{quantity}x **{item['name']}** for {cost} coins."),
                        mention_author=False)

    @commands.command(name="inventory", aliases=["inv"], extras={"example": "inventory"})
    async def inventory(self, ctx):
        """Show your items."""
        user = await self.bot.db.ensure_user(ctx.guild.id, ctx.author.id)
        owned = {k: q for k, q in user.get("inventory", {}).items() if q > 0}
        if not owned:
            return await ctx.reply(embed=info_embed("Inventory", "Empty."), mention_author=False)
        cursor = self.bot.db.items.find({"guild_id": ctx.guild.id, "key": {"$in": list(owned)}})
        names = {d["key"]: d["name"] for d in [x async for x in cursor]}
        lines = [f"{q}x {names.get(k, k + ' (removed from game)')}" for k, q in owned.items()]
        await ctx.reply(embed=info_embed("Inventory", "\n".join(lines)[:4000]), mention_author=False)

    @commands.command(name="equip", extras={"example": "equip Iron Sword"})
    async def equip(self, ctx, *, item_name: str):
        """Equip a weapon, armor or accessory from your inventory."""
        user = await self.bot.db.ensure_user(ctx.guild.id, ctx.author.id)
        self._need_character(user)
        key = item_name.strip().strip('"').lower()
        item = await self.bot.db.items.find_one({"guild_id": ctx.guild.id, "key": key})
        if not item or user.get("inventory", {}).get(key, 0) < 1:
            raise commands.BadArgument(f"You do not own an item named `{item_name.strip()[:40]}`.")
        if item["type"] not in config.EQUIP_SLOTS:
            raise commands.BadArgument("That item cannot be equipped. Try the use command.")
        equipped = await load_equipped(self.bot.db, ctx.guild.id, user)
        equipped[item["type"]] = item
        new_power = gear_power(equipped.values())
        if new_power > config.GEAR_POWER_CAP:
            raise commands.BadArgument(
                f"Equipping this would raise your gear power to {new_power:.0f}, above the cap of "
                f"{config.GEAR_POWER_CAP:.0f}. Unequip something first.")
        await self.bot.db.users.update_one({"guild_id": ctx.guild.id, "user_id": ctx.author.id},
                                           {"$set": {f"equipment.{item['type']}": key}})
        await ctx.reply(embed=success_embed("Equipped", f"**{item['name']}** in your {item['type']} slot."),
                        mention_author=False)

    @commands.command(name="unequip", extras={"example": "unequip weapon"})
    async def unequip(self, ctx, slot: str):
        """Remove the item in a slot (weapon, armor, accessory)."""
        slot = slot.lower()
        if slot not in config.EQUIP_SLOTS:
            raise commands.BadArgument(f"Slot must be one of: {', '.join(config.EQUIP_SLOTS)}.")
        await self.bot.db.ensure_user(ctx.guild.id, ctx.author.id)
        await self.bot.db.users.update_one({"guild_id": ctx.guild.id, "user_id": ctx.author.id},
                                           {"$unset": {f"equipment.{slot}": ""}})
        await ctx.reply(embed=success_embed("Unequipped", f"Your {slot} slot is empty."), mention_author=False)

    @commands.command(name="use", extras={"example": "use Health Potion"})
    async def use(self, ctx, *, item_name: str):
        """Use a consumable from your inventory."""
        user = await self.bot.db.ensure_user(ctx.guild.id, ctx.author.id)
        self._need_character(user)
        key = item_name.strip().strip('"').lower()
        item = await self.bot.db.items.find_one({"guild_id": ctx.guild.id, "key": key})
        if not item or item["type"] != "consumable":
            raise commands.BadArgument(f"`{item_name.strip()[:40]}` is not a consumable item.")
        who = {"guild_id": ctx.guild.id, "user_id": ctx.author.id}
        res = await self.bot.db.users.update_one({**who, f"inventory.{key}": {"$gte": 1}},
                                                 {"$inc": {f"inventory.{key}": -1}})
        if not res.modified_count:
            raise commands.BadArgument(f"You do not own `{item['name']}`.")
        equipped = await load_equipped(self.bot.db, ctx.guild.id, user)
        max_hp = total_stats(user["character"]["stats"], equipped.values())["hp"]
        heal = int(item["stats"].get("hp", 0))
        # Atomic heal: no stale-read race if the command is spammed.
        await self.bot.db.users.update_one(
            who, [{"$set": {"hp": {"$min": [max_hp, {"$add": [{"$ifNull": ["$hp", 0]}, heal]}]}}}])
        fresh = await self.bot.db.users.find_one(who)
        await ctx.reply(embed=success_embed("Used", f"**{item['name']}** - HP {fresh.get('hp', 0)}/{max_hp}"),
                        mention_author=False)


async def setup(bot):
    await bot.add_cog(Player(bot))
