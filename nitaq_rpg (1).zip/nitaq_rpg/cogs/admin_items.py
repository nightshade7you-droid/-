"""Admin-driven dynamic items."""
import logging

import discord
from discord.ext import commands
from pymongo.errors import DuplicateKeyError

import config
from core.balance import evaluate_item
from core.database import utcnow
from core.parsing import get_int, parse_kv, reject_unknown, validate_name
from core.ui import error_embed, format_stats, info_embed, success_embed

log = logging.getLogger("rpg.items")

ITEM_KEYS = {"type", "rarity", "price", "hp", "atk", "def", "spd", "desc"}


class AdminItems(commands.Cog, name="Items"):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="item_create",
                      extras={"example": 'item_create "Iron Sword" type=weapon rarity=common price=60 atk=8 desc="A plain blade"'})
    @commands.has_permissions(manage_guild=True)
    async def item_create(self, ctx, name: str, *, options: str):
        """Create an item (options: type rarity price hp atk def spd desc)."""
        name = validate_name(name, label="Item name")
        opts = parse_kv(options)
        reject_unknown(opts, ITEM_KEYS)

        item_type = opts.get("type", "").lower()
        if item_type not in config.ITEM_TYPES:
            raise commands.BadArgument(f"`type` must be one of: {', '.join(config.ITEM_TYPES)}.")
        rarity = opts.get("rarity", "").lower()
        if rarity not in config.RARITY_POWER_CAPS:
            raise commands.BadArgument(f"`rarity` must be one of: {', '.join(config.RARITY_POWER_CAPS)}.")
        price = get_int(opts, "price", minimum=1, maximum=10_000_000)
        stats = {}
        for stat in config.STATS:
            if stat in opts:
                value = get_int(opts, stat, minimum=1, maximum=500)
                stats[stat] = value

        ok, problems, power, min_price = evaluate_item(item_type, rarity, stats, price)
        if not ok:
            embed = error_embed("Balance Check Failed", f"**{name}** was NOT saved.")
            embed.add_field(name="Problems", value="\n".join(f"- {p}" for p in problems)[:1000], inline=False)
            return await ctx.reply(embed=embed, mention_author=False)

        doc = {"guild_id": ctx.guild.id, "name": name, "key": name.lower(), "type": item_type, "rarity": rarity,
               "price": price, "stats": stats, "power": power, "description": opts.get("desc", "")[:200],
               "created_by": ctx.author.id, "created_at": utcnow()}
        try:
            await self.bot.db.items.insert_one(doc)
        except DuplicateKeyError:
            raise commands.BadArgument(f"An item named `{name}` already exists.")
        log.info("Item created guild=%s by=%s type=%s rarity=%s", ctx.guild.id, ctx.author.id, item_type, rarity)
        embed = success_embed("Item Created", f"**{name}** ({rarity} {item_type})")
        embed.add_field(name="Stats", value=format_stats(stats, signed=True), inline=False)
        embed.add_field(name="Price", value=f"{price} coins (min {min_price})", inline=True)
        await ctx.reply(embed=embed, mention_author=False)

    @commands.command(name="item_delete", extras={"example": "item_delete Iron Sword"})
    @commands.has_permissions(manage_guild=True)
    async def item_delete(self, ctx, *, name: str):
        """Delete an item from the game."""
        res = await self.bot.db.items.delete_one({"guild_id": ctx.guild.id, "key": name.strip().strip('"').lower()})
        if not res.deleted_count:
            raise commands.BadArgument(f"No item named `{name.strip()[:40]}`.")
        await ctx.reply(embed=success_embed("Item Deleted", name.strip()), mention_author=False)

    @commands.command(name="item_info", extras={"example": "item_info Iron Sword"})
    async def item_info(self, ctx, *, name: str):
        """Show the details of an item."""
        item = await self.bot.db.items.find_one({"guild_id": ctx.guild.id, "key": name.strip().strip('"').lower()})
        if not item:
            raise commands.BadArgument(f"No item named `{name.strip()[:40]}`.")
        embed = info_embed(item["name"], item.get("description") or "No description.")
        embed.add_field(name="Type", value=f"{item['rarity']} {item['type']}", inline=True)
        embed.add_field(name="Price", value=f"{item['price']} coins", inline=True)
        embed.add_field(name="Stats", value=format_stats(item["stats"], signed=True), inline=False)
        await ctx.reply(embed=embed, mention_author=False)

    @commands.command(name="give_item", extras={"example": 'give_item @Player "Iron Sword" 1'})
    @commands.has_permissions(manage_guild=True)
    async def give_item(self, ctx, member: discord.Member, item_name: str, quantity: int = 1):
        """Give an item to a player."""
        if not 1 <= quantity <= 99:
            raise commands.BadArgument("`quantity` must be between 1 and 99.")
        item = await self.bot.db.items.find_one({"guild_id": ctx.guild.id, "key": item_name.strip().lower()})
        if not item:
            raise commands.BadArgument(f"No item named `{item_name[:40]}`.")
        await self.bot.db.ensure_user(ctx.guild.id, member.id)
        await self.bot.db.users.update_one({"guild_id": ctx.guild.id, "user_id": member.id},
                                           {"$inc": {f"inventory.{item['key']}": quantity}})
        await ctx.reply(embed=success_embed("Item Given", f"{quantity}x **{item['name']}** to {member.mention}."),
                        mention_author=False)

    @commands.command(name="give_coins", extras={"example": "give_coins @Player 500"})
    @commands.has_permissions(manage_guild=True)
    async def give_coins(self, ctx, member: discord.Member, amount: int):
        """Give coins to a player."""
        if not 1 <= amount <= 1_000_000:
            raise commands.BadArgument("`amount` must be between 1 and 1000000.")
        await self.bot.db.ensure_user(ctx.guild.id, member.id)
        await self.bot.db.users.update_one({"guild_id": ctx.guild.id, "user_id": member.id}, {"$inc": {"coins": amount}})
        await ctx.reply(embed=success_embed("Coins Given", f"{amount} coins to {member.mention}."), mention_author=False)

    @commands.command(name="item_edit", extras={"example": 'item_edit "Iron Sword" price=80 atk=9'})
    @commands.has_permissions(manage_guild=True)
    async def item_edit(self, ctx, name: str, *, options: str):
        """Edit an item (options: rarity price hp atk def spd desc). Use stat=0 to remove a stat."""
        item = await self.bot.db.items.find_one(
            {"guild_id": ctx.guild.id, "key": validate_name(name, label="Item name").lower()})
        if not item:
            raise commands.BadArgument(f"No item named `{name.strip()[:40]}`.")
        opts = parse_kv(options)
        reject_unknown(opts, ITEM_KEYS - {"type"})
        rarity = opts.get("rarity", item["rarity"]).lower()
        if rarity not in config.RARITY_POWER_CAPS:
            raise commands.BadArgument(f"`rarity` must be one of: {', '.join(config.RARITY_POWER_CAPS)}.")
        price = get_int(opts, "price", default=item["price"], minimum=1, maximum=10_000_000)
        stats = dict(item["stats"])
        for stat in config.STATS:
            if stat in opts:
                value = get_int(opts, stat, minimum=0, maximum=500)
                if value == 0:
                    stats.pop(stat, None)
                else:
                    stats[stat] = value
        ok, problems, power, min_price = evaluate_item(item["type"], rarity, stats, price)
        if not ok:
            embed = error_embed("Balance Check Failed", f"**{item['name']}** was NOT changed.")
            embed.add_field(name="Problems", value="\n".join(f"- {p}" for p in problems)[:1000], inline=False)
            return await ctx.reply(embed=embed, mention_author=False)
        await self.bot.db.items.update_one(
            {"_id": item["_id"]},
            {"$set": {"rarity": rarity, "price": price, "stats": stats, "power": power,
                      "description": opts.get("desc", item.get("description", ""))[:200]}})
        log.info("Item edited guild=%s by=%s", ctx.guild.id, ctx.author.id)
        embed = success_embed("Item Updated", f"**{item['name']}** ({rarity} {item['type']})")
        embed.add_field(name="Stats", value=format_stats(stats, signed=True), inline=False)
        embed.add_field(name="Price", value=f"{price} coins (min {min_price})", inline=True)
        await ctx.reply(embed=embed, mention_author=False)

    @commands.command(name="player_reset", extras={"example": "player_reset @Player"})
    @commands.has_permissions(manage_guild=True)
    async def player_reset(self, ctx, member: discord.Member):
        """Wipe a player's progress (character, coins, items) so they can start over."""
        res = await self.bot.db.users.delete_one({"guild_id": ctx.guild.id, "user_id": member.id})
        if not res.deleted_count:
            raise commands.BadArgument(f"{member.display_name} has no saved progress.")
        log.info("Player reset guild=%s by=%s target=%s", ctx.guild.id, ctx.author.id, member.id)
        await ctx.reply(embed=success_embed("Player Reset", f"{member.mention} can start over."), mention_author=False)


async def setup(bot):
    await bot.add_cog(AdminItems(bot))
