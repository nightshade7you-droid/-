"""RPG Discord bot engine entry point."""
import logging
import sys

import discord
from discord.ext import commands

import config
from core.database import Database
from core.errors import WrongChannel
from core.help import EmbedHelp
from core.logger import setup_logging

log = logging.getLogger("rpg.main")

EXTENSIONS = (
    "core.errors",
    "cogs.setup_cog",
    "cogs.admin_characters",
    "cogs.admin_items",
    "cogs.player",
    "cogs.economy",
    "cogs.combat",
)


class RPGBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        super().__init__(
            command_prefix=commands.when_mentioned_or(config.PREFIX),
            intents=intents,
            help_command=EmbedHelp(),
            case_insensitive=True,
        )
        self.db = None
        self.allowed_channels = {}

    async def setup_hook(self):
        self.db = Database(config.MONGO_URI, config.DB_NAME)
        await self.db.connect()
        await self.db.ensure_indexes()
        self.allowed_channels = await self.db.load_allowed_channels()
        self.add_check(self.channel_lock_check)
        for ext in EXTENSIONS:
            await self.load_extension(ext)
            log.info("Loaded extension %s", ext)

    async def channel_lock_check(self, ctx):
        if ctx.guild is None:
            raise commands.NoPrivateMessage()
        name = ctx.command.qualified_name if ctx.command else ""
        if name in config.SETUP_COMMANDS and ctx.author.guild_permissions.manage_guild:
            return True
        allowed = self.allowed_channels.get(ctx.guild.id)
        if not allowed:
            raise WrongChannel("Bot not set up in this guild")
        channel_ids = {ctx.channel.id, getattr(ctx.channel, "parent_id", None)}
        if not channel_ids & allowed:
            raise WrongChannel("Wrong channel")
        return True

    async def on_ready(self):
        log.info("Logged in as bot id %s in %d guild(s)", self.user.id, len(self.guilds))

    async def on_command_completion(self, ctx):
        log.info("Command ok: %s user=%s guild=%s", ctx.command.qualified_name, ctx.author.id, ctx.guild.id)

    async def close(self):
        if self.db:
            await self.db.close()
        await super().close()


def main():
    setup_logging()
    if not config.DISCORD_TOKEN:
        log.critical("DISCORD_TOKEN is not set. Copy .env.example to .env and fill it in.")
        sys.exit(1)
    bot = RPGBot()
    try:
        bot.run(config.DISCORD_TOKEN, log_handler=None)
    except discord.LoginFailure:
        log.critical("Invalid Discord token.")
        sys.exit(1)
    except Exception as exc:
        log.critical("Fatal startup error: %s", type(exc).__name__, exc_info=exc)
        sys.exit(1)


if __name__ == "__main__":
    main()
