"""Static configuration and balance constants. Edit numbers here to retune the game."""
import os

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

DISCORD_TOKEN = os.getenv("DISCORD_TOKEN", "")
MONGO_URI = os.getenv("MONGO_URI", "mongodb://127.0.0.1:27017")
DB_NAME = os.getenv("DB_NAME", "nitaq_rpg")
PREFIX = os.getenv("BOT_PREFIX", "=")

# Server display name (unicode escapes keep this source file pure ASCII).
SERVER_NAME = "\u0646\u0637\u0627\u0642 \u0627\u0644\u0639\u062f\u0645"

START_COINS = 100

# ---- Stats -----------------------------------------------------------------
STATS = ("hp", "atk", "def", "spd")
STAT_LABELS = {"hp": "HP", "atk": "ATK", "def": "DEF", "spd": "SPD"}
# Weight of each stat point in the "power" formula.
STAT_WEIGHTS = {"hp": 0.25, "atk": 2.0, "def": 1.5, "spd": 1.5}

# ---- Character balance -----------------------------------------------------
CHAR_STAT_RANGE = {"hp": (20, 1000), "atk": (0, 200), "def": (0, 200), "spd": (0, 200)}
TRAIT_MAX_MAGNITUDE = {"hp": 150, "atk": 25, "def": 25, "spd": 25}
BASE_POWER_CAP = 110.0        # max power of raw base stats
FINAL_POWER_CAP = 140.0       # max power after traits and flaws
FLAW_FREE_ALLOWANCE = 10.0    # trait power allowed beyond what flaws offset
MAX_TRAITS = 3
MAX_FLAWS = 3

# ---- Item balance ----------------------------------------------------------
ITEM_TYPES = ("weapon", "armor", "accessory", "consumable")
EQUIP_SLOTS = ("weapon", "armor", "accessory")
RARITY_POWER_CAPS = {"common": 20, "uncommon": 35, "rare": 55, "epic": 80, "legendary": 110}
PRICE_PER_POWER = 3           # minimum price = power * this

# ---- Name validation (unicode letters allowed, no dots or dollar signs) ----
NAME_PATTERN = r"^\w[\w '\-]{1,31}$"
TRAIT_NAME_PATTERN = r"^[\w\-]{2,24}$"

# ---- Channel-lock bypass for admins ---------------------------------------
SETUP_COMMANDS = {"setup", "channel_add", "channel_remove", "channels"}

# ---- Gear cap (stops stacking top-tier gear past the balance caps) ----------
GEAR_POWER_CAP = 120.0        # max combined power of all equipped items
SELL_RATIO = 0.5              # sell price = item price * this

# ---- Economy ---------------------------------------------------------------
DAILY_COINS = 100
DAILY_COOLDOWN = 24 * 3600
WORK_RANGE = (15, 35)
WORK_COOLDOWN = 3600
REST_COOLDOWN = 1800
FIGHT_COOLDOWN = 30

# ---- Monsters / progression ---------------------------------------------------
MONSTER_STAT_RANGE = {"hp": (1, 5000), "atk": (0, 500), "def": (0, 500), "spd": (0, 500)}
MONSTER_COIN_PER_POWER = 0.6  # max coin reward = monster power * this
MONSTER_XP_PER_POWER = 0.5    # max xp reward = monster power * this
XP_PER_LEVEL = 100
MAX_LEVEL = 50

PAGE_SIZE = 8
